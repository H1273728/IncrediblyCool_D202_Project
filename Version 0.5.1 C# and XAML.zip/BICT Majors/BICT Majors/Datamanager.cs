﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;


namespace BICT_Majors
{
    class Datamanager
    {
        SqlDataAdapter adp;
        DataTable dt;
        static int PK_ID;
        string sqlquery;

        SqlConnection con = new SqlConnection(Properties.Settings.Default.BICTConnectionString);

        public SqlCommand RunQuery(string query)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand(query, con);

            return cmd;
        }

        public void Close()
        {
            con.Close();
        }
    }
}
