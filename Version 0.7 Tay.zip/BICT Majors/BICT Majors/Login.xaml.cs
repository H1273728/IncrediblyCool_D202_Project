﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data; //added
using System.Data.SqlClient; //added

namespace BICT_Majors
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        public Window1()
        {
            InitializeComponent();

            tbxStudentId.Focus();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            // The following four lines of code was added and the rest was commented out to bypass typing in your ID and log in. Just comment this in/out and reverse the big chunk to return proper functionality.

            tbxStudentId.Text = "1717836";
            MainWindow main = new MainWindow(tbxStudentId.Text);
            this.Close();
            main.ShowDialog();

            //Datamanager dm = new Datamanager();
            //string sqlquery = "Select * From Students Where (Id= @Id And Password= @Password)";
            //string id = tbxStudentId.Text.Trim();

            //SqlCommand cmd = dm.RunQuery(sqlquery);

            //SqlParameter Id = cmd.Parameters.Add("@Id", SqlDbType.VarChar);
            //SqlParameter Password = cmd.Parameters.Add("@Password", SqlDbType.VarChar);

            //Id.Value = id;
            //Password.Value = tbxPassword.Password.ToString();

            //SqlDataReader reader = cmd.ExecuteReader();

            //if (reader.Read())
            //{
            //    string user = reader[4].ToString().Trim();
            //    if (user == "admin")
            //    {
            //        Admin admin = new Admin();
            //        this.Close();
            //        admin.ShowDialog();
            //    }
            //    else
            //    {
            //        MainWindow main = new MainWindow(Id.Value.ToString());
            //        this.Close();
            //        main.ShowDialog();
            //    }
            //}
            //else
            //{
            //    lblError.Content = "Username or Password is incorrect.";
            //    tbxPassword.Clear();
            //}
        }
    }
}
